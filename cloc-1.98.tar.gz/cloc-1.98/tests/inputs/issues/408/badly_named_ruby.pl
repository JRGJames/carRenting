#!/usr/bin/env ruby

require File.join(File.dirname(__FILE__), "/some_code.rb")
