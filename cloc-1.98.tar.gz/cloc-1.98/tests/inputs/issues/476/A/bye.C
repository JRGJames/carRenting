// bye.C
#include <iostream>
int main ()
{
    std::cout << "bye" << std::endl;  // comment 1
/*                                           2 */
}
