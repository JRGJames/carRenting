"""
    id(x)

The identity function
"""
id(x) = x
