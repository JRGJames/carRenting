let just_a_string = "
  (*
"
let x = 0
let also_a_string = "
  *)
"
let y = x
